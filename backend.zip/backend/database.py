db = {
    "business_profiles": {},      # key = owner_id, value = BusinessProfile
    "clients": {},         # key = owner_id, value = list of Client
    "bids": {},          # key = owner_id, value = list of Bid
    "subscriptions": {}  # key = uid, value = "free" or "pro"
}