from fastapi.testclient import TestClient
from backend import main

client = TestClient(main.app)

def fake_verify_firebase_token(token: str):
    return{"uid": "test-user-123"}
# Replace with a valid Firebase token for integration tests.
main.verify_firebase_token = fake_verify_firebase_token

def test_docs_page_serves():
    response = client.get("/docs")
    assert response.status_code == 200
    assert "Home Cleaner's Assistant API Docs" in response.text

def test_openapi_includes_tags():
    response = client.get("/openapi.json")
    assert response.status_code == 200
    openapi = response.json()
    assert "tags" in openapi, "No tags defined in OpenAPI schema!"
    assert any(t["name"] == "Clients" for t in openapi["tags"]), "Clients tag missing"
    assert "security" in openapi, "Global security scheme missing in OpenAPI"

def test_missing_auth_header_returns_401():
    response = client.post("/client", data={})
    assert response.status_code == 401
    assert response.json()["detail"] == "Missing Authorization Header"

def test_set_subscription_success():
    response = client.post("/set-subscription", headers=fake_verify_firebase_token(), data={"level": "pro"})
    # Depending on your dummy auth behavior, adjust expected code/response:
    assert response.status_code in (200, 401, 403)  # accept possible auth failures